package inheritancedemo.module2;
/**
 Name: Hannah Ragudos
 Date of Programming:  02/18/2023
 Activity Name: Midterm Exercise 1

 Problem and other specifications:
 The module2 package should contain 4 test classes along with other classes
 (e.g. SuperOverride, SubOverride, ...) which are the following:
 ● TestOverride
 ● TestAssign
 ● TestMethod
 ● TestInstanceOf
 Your task is to encode these classes and run them for inspection/analysis/scrutiny.
 Note that there may be other classes needed for your
 programs to work and you ensure that these files, if any, are properly included in your project folder.
 */

public class SubOverride extends SuperOverride {
    public void methodTwo() { // this overrides methodTwo() of the superclass...

// note that this is less restrictive (public
// here vis-à-vis protected in the superclass)...

        System.out.println("methodTwo from subclass...");
    }
    // this will be invalid, since the accessibility of the overriding method is
// more restrictive (i.e., from public to private)...
// private void methodOne() {}
    public void methodThree(int i) { // this method is overloaded across classes...
        System.out.println("methodThree from subclass...");
    }
}