package inheritancedemo.module2;
/**
 Name: Hannah Ragudos
 Date of Programming:  02/18/2023
 Activity Name: Midterm Exercise 1

 Problem and other specifications:
 The module2 package should contain 4 test classes along with other classes
 (e.g. SuperOverride, SubOverride, ...) which are the following:
 ● TestOverride
 ● TestAssign
 ● TestMethod
 ● TestInstanceOf
 Your task is to encode these classes and run them for inspection/analysis/scrutiny.
 Note that there may be other classes needed for your
 programs to work and you ensure that these files, if any, are properly included in your project folder.
 */

public class TestMethod {
    public static void main(String[] args) {
        SuperOverride sp; // declares a reference variable sp of type SuperOverride without initializing it.
        sp = new SuperOverride(); // creates a new object of type SuperOverride and assigns it to the variable sp.

        sp.methodTwo(); // calls superclass methodTwo()...
        /**
         * Calls the methodTwo() method on the object referred to by the sp variable.
         * Since the object is an instance of SuperOverride, the implementation of
         * the methodTwo() method in the superclass is executed.
         */

        sp = new SubOverride();
        /**
         * Creates a new object of type SubOverride and assigns it to the variable sp,
         * which still has a declared type of SuperOverride.
         */

        sp.methodTwo(); // calls subclass methodTwo()... note that the
        /**
         * Calls the methodTwo() method on the object referred to by the sp variable.
         * Since the object is an instance of SubOverride, the implementation of
         * the methodTwo() method in the subclass is executed.
         */

    } // same object variable (sp) is used in both
}

