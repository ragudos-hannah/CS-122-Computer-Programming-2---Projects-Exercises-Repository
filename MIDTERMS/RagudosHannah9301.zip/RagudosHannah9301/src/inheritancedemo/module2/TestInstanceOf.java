package inheritancedemo.module2;

/**
 Name: Hannah Ragudos
 Date of Programming:  02/18/2023
 Activity Name: Midterm Exercise 1

 Problem and other specifications:
 The module2 package should contain 4 test classes along with other classes
 (e.g. SuperOverride, SubOverride, ...) which are the following:
 ● TestOverride
 ● TestAssign
 ● TestMethod
 ● TestInstanceOf
 Your task is to encode these classes and run them for inspection/analysis/scrutiny.
 Note that there may be other classes needed for your
 programs to work and you ensure that these files, if any, are properly included in your project folder.
 */

public class TestInstanceOf {

    /**
     * This method takes an object of type Object as a parameter and returns a String indicating
     * the type of the object. It uses the instanceof operator to check whether the object is an
     * instance of SubOverride, SuperOverride, or neither.*/
    public static String instanceName(Object o) {
        if (o instanceof SubOverride)
            return "Sub";
        else
        if (o instanceof SuperOverride)
            return "Super";
        else
            return "Something Else";

    }

    /**
     * This main() method creates three objects of different types and passes them
     * to the instanceName() method to determine their types*/
    public static void main(String[] args) {

        /**
         *Creates a new object of type SuperOverride and assigns it to a variable of type Object.
         * This is allowed because SuperOverride is a subclass of Object. When the instanceName()
         * method is called with this object as a parameter, it returns "Super" because the
         * object is an instance of SuperOverride.
         */
        Object o = new SuperOverride();
        System.out.println(instanceName(o)); // prints ”Super”...

        /**
         * Creates a new object of type SubOverride and assigns it to the same variable o.
         * When the instanceName() method is called with this object as a parameter, it
         * returns "Sub" because the object is an instance of SubOverride.
         */
        o = new SubOverride();
        System.out.println(instanceName(o)); // prints ”Sub”...

        /**
         * Creates a new object of type Object and assigns it to the same variable o.
         * When the instanceName() method is called with this object as a parameter, it
         * returns "Something Else" because the object is not an instance of either
         * SubOverride or SuperOverride.
         */
        o = new Object();
        System.out.println(instanceName(o)); // prints ”Something Else”...
    }
}