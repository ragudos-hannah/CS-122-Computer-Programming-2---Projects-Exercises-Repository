package inheritancedemo.module2;

/**
 Name: Hannah Ragudos
 Date of Programming:  02/18/2023
 Activity Name: Midterm Exercise 1

 Problem and other specifications:
 The module2 package should contain 4 test classes along with other classes
 (e.g. SuperOverride, SubOverride, ...) which are the following:
 ● TestOverride
 ● TestAssign
 ● TestMethod
 ● TestInstanceOf
 Your task is to encode these classes and run them for inspection/analysis/scrutiny.
 Note that there may be other classes needed for your
 programs to work and you ensure that these files, if any, are properly included in your project folder.
 */

public class TestAssign {
    public static void main(string[] args) {

        SuperOverride sp;
        SubOverride sb;
        sp = new SubOverride(); // this is allowed...
        /**
         * This is allowed to assign an instance of SubOverride to a variable of
         * type SuperOverride, but the reverse is not allowed.
         */

        sb = new SuperOverride(); // but not this, so comment it out...this should be sb = (SubOverride) new SuperOverride();
        /**
         * Subclass reference variable can't hold super class subject,
         * making the linecause compile time error.
         */


        Object o = new SuperOverride(); // this works, since Object is a superclass of all other classes...
        /**
         * This statement creates an object of SuperOverride and assigns it to a variable
         * of type Object. This is allowed because Object is the superclass of all classes in Java.
         */


        sp = o; // this won’t work, so comment it out...this should be  sp = (SuperOverride) o
        /**
         * This statement attempts to assign an Object to a variable of type SuperOverride,
         * but this won't work without typecasting, since the subclass reference variable
         * can't hold superclass reference variable
         */

        sp = (SuperOverride) o; // but this will...
        /**
         * This will not give compile runtime error, because casts the Object to SuperOverride,
         * which is allowed because the Object is actually an instance of SuperOverride.
         */

        sb = (SubOverride) o; // this will compile, but will cause
        /**
         * This statement attempts to cast the Object to SubOverride, but this will cause a runtime error.
         * The reason is that the Object is not actually an instance of SubOverride, but a ClassCastException
         * is not thrown until the cast is attempted at runtime. This is because the object referred to by
         * the Object variable is not an instance of SubOverride or any of its subclasses.
         */



    } // a run-time error when executed...
} // try to determine why :-)...