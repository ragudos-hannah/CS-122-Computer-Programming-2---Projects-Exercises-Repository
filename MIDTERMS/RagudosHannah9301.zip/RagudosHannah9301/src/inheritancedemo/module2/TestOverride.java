package inheritancedemo.module2;

/**
 Name: Hannah Ragudos
 Date of Programming:  02/18/2023
 Activity Name: Midterm Exercise 1

 Problem and other specifications:
 The module2 package should contain 4 test classes along with other classes
 (e.g. SuperOverride, SubOverride, ...) which are the following:
 ● TestOverride
 ● TestAssign
 ● TestMethod
 ● TestInstanceOf
 Your task is to encode these classes and run them for inspection/analysis/scrutiny.
 Note that there may be other classes needed for your
 programs to work and you ensure that these files, if any, are properly included in your project folder.
 */

public class TestOverride {
    // main method
    public static void main(String[] args) {
        /**
         * Creates a new object of the SubOverride class and assigns it to
         * a reference variable named sb.
         */
        SubOverride sb = new SubOverride ();

        /**
         * Calls the methodOne() method on the object referred to by the sb variable.
         * Since the methodOne() method is not overridden in the SubOverride class,
         * the implementation of the methodOne() method in the superclass
         * (SuperOverride) is executed.*/
        sb.methodOne();

        /**
         * Calls the methodTwo() method on the object referred to by the sb variable.
         * Since the methodTwo() method is overridden in the SubOverride class,
         * the implementation of the methodTwo() method in the subclass is executed.
         */
        sb.methodTwo();

        /**
         * Calls the methodThree() method on the object referred to by the sb variable.
         * Since the methodThree() method is overridden in the SubOverride class,
         * the implementation of the methodThree() method in the subclass is executed.
         */
        sb.methodThree();

        /**
         *  Calls the methodThree() method on the object referred to by the sb variable.
         *  Since the methodThree() method is overridden in the SubOverride class,
         *  the implementation of the methodThree() method in the subclass is executed again.
         */
        sb.methodThree();
    }
}
