/**
 Name: Hannah Ragudos
 Date of Programming:  03/28/2023
 Activity Name: Midterm Exercise
 Specifications: This program arranges student list based on their names

 Sample Run:

 Original order
 Raba,89.0
 Anne,85.0
 John,99.0
 Lene,70.0

 Arranged Students
 Anne,85.0
 John,99.0
 Lene,70.0
 Raba,89.0

 */
public class RagudosHannahStudentList {
    public static void main(String[] args) {
        RagudosHannahStudentList myProgram = new RagudosHannahStudentList();
        myProgram.run();
    }

    public void run() {
        RagudosHannahStudent[] studs = new RagudosHannahStudent[4];
        studs[2] = new RagudosHannahStudent();
        studs[1] = new RagudosHannahStudent("Anne", 85);
        studs[0] = new RagudosHannahStudent("Raba", 89);
        studs[3] = new RagudosHannahStudent("Lene", 70);

        // shows the original order of the student list
        System.out.println();
        System.out.println("Original order");
        showStudents(studs);

        // shows the arranged order of the student list alphabetically
        System.out.println();
        System.out.println("Arranged Students");
        // Collections.sort(studs);  if studs is an ArrayList of Student
        sortStudents(studs);
        showStudents(studs);

    }

    /**
     * This method let the console show the list of Students
     * @param ragudosHannahStudents the list of students
     */
    public void showStudents(RagudosHannahStudent[] ragudosHannahStudents) {
        for (int index = 0; index < ragudosHannahStudents.length; index++) {
            System.out.println(ragudosHannahStudents[index]);
        }
    }

    /**
     * This method allows the user see the sorted list of the students
     * @param s the sorted list of students
     */
    public static void sortStudents(RagudosHannahStudent[] s) {
        RagudosHannahStudent temp;
        int minIndex = 0;
        for (int x = 0; x < s.length - 1; x++) {
            minIndex = x;
            for (int y = x + 1; y < s.length; y++) {
                if
                (s[minIndex].getName().compareToIgnoreCase(s[y].getName()) > 0)
                    minIndex = y;
                if
                (s[minIndex].getName().compareToIgnoreCase(s[y].getName()) > 0)
                    minIndex = y;
            }
            if (minIndex != x) {
                temp = s[x];
                s[x] = s[minIndex];
                s[minIndex] = temp;
            }
        }
    }
}