/**
 Name: Hannah Ragudos
 Date of Programming:  03/28/2023
 Activity Name: Midterm Exercise

 Sample Run:
 Original order
 John,99.0
 Anne,85.0
 Raba,89.0
 Lene,70.0

 Arranged Students
 Anne,85.0
 John,99.0
 Lene,70.0
 Raba,89.0
 */

import java.util.ArrayList;
import java.util.Collections;

public class RagudosHannahStudentList2 {
    public static void main(String[] args) {
        RagudosHannahStudentList2 myProgram = new RagudosHannahStudentList2();
        myProgram.run();
    }

    public void run(){
        ArrayList<RagudosHannahStudent> studs = new ArrayList<>();
        studs.add(new RagudosHannahStudent());
        studs.add(new RagudosHannahStudent("Anne", 85));
        studs.add(new RagudosHannahStudent("Raba", 89));
        studs.add(new RagudosHannahStudent("Lene", 70));
        System.out.println();
        System.out.println("Original order");
        showStudents(studs);
        System.out.println();
        System.out.println("Arranged Students");
        Collections.sort(studs);  //if studs is an ArrayList of Student
        showStudents(studs);

    }

    /**
     * This method allows the user see the sorted list of the students
     */
    public void showStudents(ArrayList<RagudosHannahStudent> ragudosHannahStudents){
        for (int index = 0; index< ragudosHannahStudents.size(); index++){
            System.out.println(ragudosHannahStudents.get(index));
        }
    }

}
