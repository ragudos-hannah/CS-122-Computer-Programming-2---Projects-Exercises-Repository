/**
 Name: Hannah Ragudos
 Date of Programming:  03/28/2023
 Activity Name: Midterm Exercise
 */

public class RagudosHannahStudent implements Comparable<RagudosHannahStudent> {
    private String name;
    private double gwa;

    public RagudosHannahStudent(){
        name = "John";
        gwa = 99.0;
    }

    public RagudosHannahStudent(String n, double g){
        this.name=n;
        this.gwa=g;
    }

    // getters here
    public String getName(){
        return name;
    }
    public double getGWA(){
        return gwa;
    }

    // setters here
    public void setName(String name) {
        this.name = name;
    }

    public void setGwa(double gwa) {
        this.gwa = gwa;
    }

    public String toString() {
        return name + "," + gwa;
    }

    public int compareTo(RagudosHannahStudent another){
        return (this.getName().compareToIgnoreCase(another.getName()));


        /*
        // the code below may be used if comparing will be based on gwa
        int result=0;
        if (this.gwa < another.getGWA())
            result = -1;
        else
            if (this.gwa > another.getGWA())
                result = 1;
            else
                result = 0;
        return result;

         */

    }
}
