/**
 * Name: Ragudos, Hannah T.
 * Class Code and Schedule: 9301 TF-7:30-10:30
 * Date: March 31, 2023
 *
 * Sample Run:
 * <p>
 *     Case 1:
 *      This program helps you divide whole numbers.
 *      Enter the dividend:
 *      14
 *      Enter the divisor:
 *      2
 *      14/2=7
 *      Have a good day!
 *
 *     Case 2:
 *     This program helps you divide whole numbers.
 *     Enter the dividend:
 *     1
 *     You have entered an invalid integer
 *     For input string: " 1"
 *     Enter the dividend:
 *     2
 *     Enter the divisor:
 *     0
 *     zero denominator should be avoided
 *     Division was not done because the divisor is 0.
 *     Have a good day!
 * </p>
 */

import java.util.Scanner;
public class ExceptionExerciseProgram {
    private static ExceptionExerciseProgram test;

    public static void main(String[] args) {
        ExceptionExerciseProgram test;
        try{
            test = new  ExceptionExerciseProgram();
            test.run();
        }
        catch (ArithmeticException e1) {
            System.out.println(e1.getMessage());
            System.out.println("Division was not done because the divisor is 0.");
        }
        catch (Exception e2){
            e2.printStackTrace();
        }
        finally {
            System.out.println("Have a good day!");
            System.exit(0);
        }
    } // end of main method

    // A method that propagates exception
    public void run () throws ArithmeticException, Exception{
        Scanner scanner = new Scanner(System.in);
        System.out.println("This program helps you divide whole numbers.");
        int x = readInteger("Enter the dividend");
        int y = readInteger ("Enter the divisor");
        if (y==0)
            throw new ArithmeticException("zero denominator should be avoided");
        System.out.println(x+"/"+y+"="+x/y);
    } // end of run method

    // A method that handles an exception
    private int readInteger (String prompt) {
        Scanner scanner = new Scanner(System.in);
        int result = 0;
        boolean validValueRead = false;
        while (!validValueRead){
            try {
                System.out.println(prompt+":");
                result = Integer.parseInt(scanner.nextLine());
                validValueRead= true;
            } catch (NumberFormatException ex){
                System.out.println("You have entered an invalid integer");
                System.out.println(ex.getMessage());
            }
        } // end of while
        return result;
    } // end of readInteger method
} // end of class
