/**
 * Name: Ragudos, Hannah T.
 * Class Code and Schedule: 9301 TF-7:30-10:30
 * Date: March 31, 2023
 */
public class Student implements Comparable<Student> {
    private String name;
    private double average;

    public Student(){
        name = "Bong";
        average = 75.0;
    }

    public Student(String n, double g){
        this.name=n;
        this.average=g;
    }

    // getters here
    public String getName(){
        return name;
    }
    public double getAverage(){
        return average;
    }
    // other methods may be placed here

    public boolean equals (Object another) {
        return (this.toString().equals(((Student) another).toString()));
    }

    public String toString(){
        return name+","+average;
    }
    public int compareTo(Student another){
        return (another.getName().compareToIgnoreCase(this.getName()));
    }
}
