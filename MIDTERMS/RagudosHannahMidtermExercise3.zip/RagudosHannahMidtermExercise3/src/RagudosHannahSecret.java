/**
 *  Name: Hannah Ragudos
 *  Date of Programming:  03/14/2023
 *  Activity Name: Midterm Exercise 3
 *  <p>
 *      This is the RagudosHannahSecret class, which implements the Encryptable interface
 *      and provides an implementation of the XOR Cipher encryption algorithm. The class
 *      takes a message as input, and generates a random key to encrypt the message. The
 *      class provides methods to encrypt and decrypt the message, as well as to check
 *      whether the message is already encrypted. This class provides a secure way of
 *      encrypting and decrypting messages in Java, and can be used in any application
 *      that requires secure transmission of data.
 *  </p>
*/

import java.lang.*;
import java.util.Random;

public class RagudosHannahSecret implements Encryptable {
    private String message;
    private boolean encrypted;
    private byte[] key;

    public RagudosHannahSecret(String givenMessage){
        message = givenMessage;
        encrypted = false;
        Random generator = new Random();
        key = new byte[8];
        generator.nextBytes(key);
    }

    /**
     * Replaces the value of message to its encrypted form by applying the XOR Cipher encryption algorithm
     */
    public void encrypt(){
        if (!encrypted) {
            byte[] messageBytes = message.getBytes();
            byte[] encryptedBytes = new byte[messageBytes.length];
            for (int i = 0; i < messageBytes.length; i++) {
                encryptedBytes[i] = (byte) (messageBytes[i] ^ key[i % key.length]);
            }
            message = new String(encryptedBytes);
            encrypted = true;
        }
    }

    /**
     * Returns the unencrypted form of the value of message
     */
    public String decrypt(){
        if (encrypted){
            byte[] encryptedBytes = message.getBytes();
            byte[] decryptedBytes = new byte[encryptedBytes.length];
            for (int i = 0; i < encryptedBytes.length; i++) {
                decryptedBytes[i] = (byte) (encryptedBytes[i] ^ key[i % key.length]);
            }
            message = new String(decryptedBytes);
            encrypted = false;
        }
        return message;
    }

    /**
     * Returns the value of encrypted
     */
    public boolean isEncrypted(){
        return encrypted;
    }

    /**
     * Returns the value of message
     */
    public String toString(){
        return message;
    }
} // end of RagudosHannahSecret class