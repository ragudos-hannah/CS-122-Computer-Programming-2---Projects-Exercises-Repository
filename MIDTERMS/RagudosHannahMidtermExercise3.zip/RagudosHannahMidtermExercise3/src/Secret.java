/**
 *  Name: Hannah Ragudos
 *  Date of Programming:  03/14/2023
 *  Activity Name: Midterm Exercise 3
 *  <p>
 *      This is the Secret class, which implements the Encryptable interface and provides an
 *      implementation of the Caesar Cipher encryption algorithm. The class takes a message
 *      as input, and generates a random shift value to encrypt the message using the Caesar
 *      Cipher algorithm. The class provides methods to encrypt and decrypt the message, as
 *      well as to check whether the message is already encrypted. This class provides a simple
 *      way of encrypting and decrypting messages in Java, and can be used in any application
 *      that requires basic encryption and decryption capabilities.
 *  </p>
 */

import java.lang.*;
import java.util.Random;

public class Secret implements Encryptable {
    private String message;
    private boolean encrypted;
    private int shift;
    private Random generator;

    public Secret(String givenMessage){
        message = givenMessage; /* assign givenMessage to message */
        encrypted = false; /* assign false to encrypted */
        generator = new Random(); /* construct an object of Random and assign it to generator */
        shift = generator.nextInt(10) + 5; /* Use generator to produce an integer that is at most 9, add 5 to the generated random number and assign the sum to shift */
    }

    /**
     Replaces the value of message to its encrypted form by applying the Caesar Cipher encryption algorithm
     */
    public void encrypt(){
        if (!encrypted) {
            String encryptedMessage ="";
            for (int index=0; index < message.length(); index++)
                encryptedMessage = encryptedMessage + (char) (message.charAt(index)+shift);
            message = encryptedMessage;
            encrypted = true;
        }
    }

    /**
     * Returns the unencrypted form of the value of message
     *
     * @return
     */
    public String decrypt(){
        if (encrypted){
            String decryptedMessage ="";
            for (int index=0; index<message.length(); index++)
                decryptedMessage = decryptedMessage + (char) (message.charAt(index)-shift);
            message = decryptedMessage;
            encrypted = false;
        }
        return message;
    }

    /**
     Returns in value of encrypted
     */
    public boolean isEncrypted(){
        return encrypted;
    }

    /**
     Returns the value of message
     */
    public String toString(){
        return message;
    }
} // end of Secret class