/**
 *  Name: Hannah Ragudos
 *  Date of Programming:  03/14/2023
 *  Activity Name: Midterm Exercise 3
 *  <p>
 *       This is the SecretTest class, which is used to test the functionality of the Secret class.
 *       The class creates an instance of the Secret class, and uses its encrypt() and decrypt()
 *       methods to encrypt and decrypt a message, respectively. This class provides a simple
 *       way of testing the functionality of the Secret class, and can be extended to test
 *       additional encryption and decryption algorithms as needed.
 *  </p>
 */

public class SecretTest {
    public static void main(String[] args){
        Secret sample = new Secret("The quick brown fox jumped over the lazy dog");

        System.out.print("Message to be encrypted: ");
        System.out.println(sample.toString());
        sample.encrypt(); /*Encrypt by invoking the encrypt method*/

        System.out.print("Encrypted Message: ");
        System.out.println(sample.toString());
        System.out.print("Result of Decryption: ");

        sample.decrypt(); /*Decrypt by invoking the decrypt method*/
        System.out.println(sample.toString());

        System.exit(0);
    }
} // end of SecretTest class