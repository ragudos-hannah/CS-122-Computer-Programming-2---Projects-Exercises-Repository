/**
 *  Name: Hannah Ragudos
 *  Date of Programming:  03/14/2023
 *  Activity Name: Midterm Exercise 3
 *  <p>
 *       This is the Encryptable interface, which defines the methods that any class implementing
 *       this interface must provide. The interface defines two methods - encrypt() and decrypt() -
 *       which are responsible for encrypting and decrypting data, respectively. Any class that
 *       implements this interface must provide an implementation for both of these methods. This
 *       interface provides a standard way of encrypting and decrypting data in Java, making it
 *       easier to write secure and maintainable code.
 *  </p>
*/
public interface Encryptable {
    public void encrypt();
    public String decrypt();
}// end of Encryptable interface