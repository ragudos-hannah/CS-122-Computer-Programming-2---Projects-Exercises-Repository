/**
 * Name: Ragudos, Hannah T.
 * Date of Programming: 04/25/2023
 * Activity Name: Midterm Exercise: Final Laboratory Exercise 1
 * Specifications:
 *  The probable age during which a person may get married is computed
 *  as the person's current age plus a random integer from 0 to 29.
 *  Create a Java appliation that will determine and show the probable
 *  age during which a person may get married.
 */

package prog2.samcis.edu;

public interface MyFunctionalInterface {
    public String provideResponse(int seed);
}
