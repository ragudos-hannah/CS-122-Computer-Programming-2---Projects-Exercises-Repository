/**
 * Name: Ragudos, Hannah T.
 * Date of Programming: 04/25/2023
 * Activity Name: Midterm Exercise: Final Laboratory Exercise 1
 * Specifications:
 *  The probable age during which a person may get married is computed
 *  as the person's current age plus a random integer from 0 to 29.
 *  Create a Java application that will determine and show the probable
 *  age during which a person may get married.
 */

package prog2.samcis.edu;

import javax.swing.*;
import java.util.Random;
import java.util.Scanner;

public class TestClass2 {
    public static void main(String[] args) {
        TestClass2 program;
        Random generator = new Random();
        try{
            program = new TestClass2();
            program.run((x) -> {
                String name = JOptionPane.showInputDialog("What is your name?");
                String result = "Hello"+name+", you are expect to be married when you are "+(x+generator.nextInt(30))+" years old";
                return result;
            });
        } catch (Exception exception){
            System.out.println(exception.getMessage());
        }
        System.exit(0);
    } // end of main method
    public void run (MyFunctionalInterface predictor) throws Exception{

        int age = Integer.parseInt(JOptionPane.showInputDialog("What is your current age?"));
        JOptionPane.showMessageDialog(null, predictor.provideResponse(age));
    } // end of run method
} // end of TesterClass2
