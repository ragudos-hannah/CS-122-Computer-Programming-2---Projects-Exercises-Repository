/**
 * Name: Ragudos, Hannah T.
 * Date of Programming: 04/25/2023
 * Activity Name: Midterm Exercise: Final Laboratory Exercise 1
 * Specifications:
 *  The probable age during which a person may get married is computed
 *  as the person's current age plus a random integer from 0 to 29.
 *  Create a Java appliation that will determine and show the probable
 *  age during which a person may get married.
 */

package prog2.samcis.edu;

import javax.swing.*;
import java.util.Random;
import java.util.Scanner;

public class TestClass1 {
    public static void main(String[] args) {
        TestClass1 program;
        try{
            program = new TestClass1();
            program.run();
        } catch (Exception exception){
            System.out.println(exception.getMessage());
        }
        System.exit(0);
    }
    public void run () throws  Exception{
        Scanner keyboard = new Scanner(System.in);
        Random generator = new Random();

        MyFunctionalInterface predictor = x -> {
            // System.out.println("What is your name?");
            // String name = keyboard.nextLine();
            String name = JOptionPane.showInputDialog("What is your name?");
            String result = "Hello"+name+",expect to be married when you are "+(x+generator.nextInt(30))+" years old";
            return result;
        };
        // System.out.println("How old are you?");
        // int age = Integer.parseInt(keyboard.nextLine());

        int age = Integer.parseInt(JOptionPane.showInputDialog("What is your current age?"));
        // System.out.println(predictor.provideResponse(age));
        JOptionPane.showMessageDialog(null, predictor.provideResponse(age));
    } // end of main method
} // end of TesterClass1
