/**
 * Name: Ragudos, Hannah T.
 * Date of Programming: 04/28/2023
 * Activity Name: Midterm Exercise: Activity Using Java Stream API
 * Sample Run:
 * 
 */

package prog2.samcis.edu;

import java.lang.*;
import java.util.*;
import java.util.ArrayList;
import java.util.List;

public class ProductRecordingUsingStream {
    public static void main(String[] args) {
        ProductRecordingUsingStream program;
        try {
            program = new ProductRecordingUsingStream();
            program.run();
        } catch (Exception x) {
            x.printStackTrace();
        }
        System.exit(0);
    } // end of main method

    public void run() throws Exception {
        // Create list of products
        List<Product>productList = new ArrayList<Product>();

        // Populate the list of products
        productList.add(new Product("1076543", "Acme", "Vacuum Cleaner", 180.11));
        productList.add(new Product("3756534", "Nadir", "Washing Machiner", 178.97));
        productList.add(new Product("1234567", "Zenith", "Fridge", 151.98));
        productList.add(new Product("7876161", "Zenith", "Tumble Drier", 159.99));

        // Display all items using stream
        /*
         *
         * Obtain in a stream from the ArrayList
         * Apply the foreach terminal operation to the stream
         */
        System.out.println("1. List of Products");
        productList.stream().forEach(product -> System.out.println(product));

        System.out.println("\n 2. List of Products");
        productList.stream().forEach(System.out::println);

        /*
        Note that for forEach(product -> System.out.println(product)) may be written as forEach(System.out::println)
         */

        // Print a blank line
        System.out.println();

        // Filter he list to display products with costs that are less than 170
        /*
         * Obtain a stream from the ArrayList
         * Apply the fikter intermediate operation to the stream
         * Apply the forEach terminal operation to the result of the filter operation
         */

        System.out.println("\n 3.Products with unit rice that is less than 170");
        productList.stream().filter(product -> product.getUnitPrice()<170).forEach(product -> System.out.println(product));

        System.out.println("\n 4. Products with unit price costing less than 170");
        productList.stream().filter(product -> product.getUnitPrice()>170).forEach(System.out::println);

        int counter = (int)  productList.stream().filter(product -> product.getUnitPrice()<170).count();

        return;
    } // end of run
} // end of class
