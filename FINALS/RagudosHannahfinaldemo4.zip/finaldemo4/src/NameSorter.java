/**
 * Name: Ragudos, Hannah T.
 * Date of Programming: 05/09/2023
 * Activity Name: finaldemo4
 *
 *Objective:
 * Create a program that implements the following:
 * 1. Balloon Sort Algorithm
 * 2. Bubble Sort Algorithm
 * 3. Selection Sort Algorithm
 *
 * Problem:
 * Read a list of names (one per line) from a text file, store these names in an array of name
 * objects, sort the name objects, then display the sorted name objects on the screen. In addition,
 * a file containing the sorted names must be created.
 *
 * Sample Run:
 * This program sorts a list of names stored in a file.
 *
 * Enter the name of the file that contains the list of names: List1.txt
 *
 * Enter the desired order:
 * [1] Ascending or [2] Descending? 2
 *
 * Enter the sorting algorithm to be applied:
 * [1] Balloon Sort Algorithm
 * [2] Bubble Sort Algorithm
 * [3] Selection Sort Algorithm? 1
 *
 * Sorting...
 *
 * DONE.
 *
 * List of Sorted Names
 * Valdez, Theodore
 * Osmena, Renator
 * Dela Cruz, Juan
 * Abad, Santos
 *
 * The sorted names are saved in SortedList1.txt
 * </p>
 */

import java.io.*;
import java.util.Scanner;

public class NameSorter {

    /**
     * Reads names from a file, creates Name objects, and stores them in an array.
     * @param fileName The name of the input file containing the list of names.
     * @return An array of Name objects.
     */
    private static Name[] readFromFile(String fileName) {
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            int numNames = Integer.parseInt(bufferedReader.readLine().trim());
            Name[] names = new Name[numNames];

            for (int i = 0; i < numNames; i++) {
                String[] nameParts = bufferedReader.readLine().split(", ");
                names[i] = new Name(nameParts[1], nameParts[0]);
            } // end of for

            bufferedReader.close(); // Close the BufferedReader
            return names;
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
            return new Name[0];
        } // End of try-catch block
    } // End of readFromFile method

    /**
     * Calls the appropriate sorting algorithm based on the user's choice.
     * @param names     The array of Name objects to be sorted.
     * @param order     The sorting order: 1 for ascending, 2 for descending.
     * @param algorithm The sorting algorithm to apply: 1 for Balloon Sort, 2 for Bubble Sort, 3 for Selection Sort.
     */
    private static void getTypeOfSort(Name[] names, int order, int algorithm) {
        switch (algorithm) {
            case 1:
                balloonSort(names, order);
                break;
            case 2:
                bubbleSort(names, order);
                break;
            case 3:
                selectionSort(names, order);
                break;
            default:
                System.out.println("Invalid sorting algorithm.");
                break;
        } // End of switch statement
    } // End of getTypeOfSort method

    /**
     * Sorts an array of Name objects using the Balloon Sort algorithm.
     * @param names The array of Name objects to be sorted.
     * @param order The sorting order: 1 for ascending, 2 for descending.
     */
    private static void balloonSort(Name[] names, int order) {
        int n = names.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = n - 1; j > i; j--) {
                if (order == 1) {
                    if (names[j].lastName.compareTo(names[j - 1].lastName) < 0) {
                        Name temp = names[j];
                        names[j] = names[j - 1];
                        names[j - 1] = temp;
                    }
                } else {
                    if (names[j].lastName.compareTo(names[j - 1].lastName) > 0) {
                        Name temp = names[j];
                        names[j] = names[j - 1];
                        names[j - 1] = temp;
                    }
                }
            } // End of inner for loop
        } // End of outer for loop
    } // End of balloonSort method

    /**
     * Sorts an array of Name objects using the Bubble Sort algorithm.
     * @param names The array of Name objects to be sorted.
     * @param order The sorting order: 1 for ascending, 2 for descending.
     */
    private static void bubbleSort(Name[] names, int order) {
        int n = names.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (order == 1) {
                    if (names[j].lastName.compareTo(names[j + 1].lastName) > 0) {
                        Name temp = names[j];
                        names[j] = names[j + 1];
                        names[j + 1] = temp;
                    }
                } else {
                    if (names[j].lastName.compareTo(names[j + 1].lastName) < 0) {
                        Name temp = names[j];
                        names[j] = names[j + 1];
                        names[j + 1] = temp;
                    }
                }
            } // End of inner for loop
        } // End of outer for loop
    } // End of bubble method

    /**
     * Sorts an array of Name objects using the Selection Sort algorithm.
     * @param names The array of Name objects to be sorted.
     * @param order The sorting order: 1 for ascending, 2 for descending.
     */
    private static void selectionSort(Name[] names, int order) {
        int n = names.length;
        for (int i = 0; i < n - 1; i++) { // Outer loop iterates through the names array
            int index = i;

            for (int j = i + 1; j < n; j++) { // Inner loop searches for the smallest or largest name depending on the order
                if (order == 1) {
                    if (names[j].lastName.compareTo(names[index].lastName) < 0) {
                        index = j;
                    }
                } else {
                    if (names[j].lastName.compareTo(names[index].lastName) > 0) {
                        index = j;
                    }
                }
            } // End of inner loop

            // Swap the name at the current index with the smallest or largest name found
            Name temp = names[index];
            names[index] = names[i];
            names[i] = temp;
        } // End of outer loop
    } // End of selectionSort method

    /**
     * Displays the sorted array of Name objects on the screen.
     * @param names The sorted array of Name objects.
     */
    private static void displayNames(Name[] names) {
        System.out.println("\nList of Sorted Names");
        for (Name name : names) {
            System.out.println(name);
        } // End of for loop
    } // End of displayNames method

    /**
     * Saves the sorted array of Name objects to a text file.
     * @param fileName The name of the output file to save the sorted names.
     * @param names    The sorted array of Name objects.
     */
    private static void saveToFile(String fileName, Name[] names) {
        try {
            FileWriter fileWriter = new FileWriter(fileName);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            for (Name name : names) {
                bufferedWriter.write(name.toString());
                bufferedWriter.newLine();
            } // End of for loop

            bufferedWriter.close();
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        } // End of try-catch
    } // End of saveToFile method

    // Main method
    public static void main(String[] args) {
        // Initialize a Scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Print the program description
        System.out.println("This program sorts a list of names stored in a file.");
        System.out.print("\nEnter the name of the file that contains the list of names: ");
        String fileName = scanner.nextLine();

        // Read names from the file and store them in an array of Name objects
        Name[] names = readFromFile(fileName);

        // Prompt the user for sorting order: ascending or descending
        System.out.print("\nEnter the desired order:\n[1] Ascending or [2] Descending? ");
        int order = scanner.nextInt();

        // Initialize a flag to control the loop for sorting and displaying names
        boolean repeat = true;
        while (repeat) {
            // Prompt the user for the sorting algorithm to be applied
            System.out.print("\nEnter the sorting algorithm to be applied:\n[1] Balloon Sort Algorithm\n[2] Bubble Sort Algorithm\n[3] Selection Sort Algorithm? ");
            int algorithm = scanner.nextInt();

            // Sort the names using the selected algorithm and order
            System.out.println("\nSorting...");
            getTypeOfSort(names, order, algorithm);
            System.out.println("\nDONE.");

            // Display the sorted names on the screen
            displayNames(names);

            // Save the sorted names to a file
            String sortedFileName = "SortedList" + algorithm + ".txt";
            saveToFile(sortedFileName, names);
            System.out.println("\nThe sorted names are saved in " + sortedFileName);

            // Ask the user if they want to repeat the process with a different sorting algorithm
            System.out.print("\nRepeat the process(Y/N)? ");
            String response = scanner.next();
            repeat = response.equalsIgnoreCase("Y");
        }
        // Close the Scanner object
        scanner.close();
    } // End of main method
} // End of NameSorter class
