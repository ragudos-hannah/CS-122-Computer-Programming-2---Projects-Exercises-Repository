/**
 * Name: Ragudos, Hannah T.
 * Date of Programming: 05/09/2023
 * Activity Name: finaldemo4
 *
 *Objective:
 * Create a program that implements the following:
 * 1. Balloon Sort Algorithm
 * 2. Bubble Sort Algorithm
 * 3. Selection Sort Algorithm
 *
 * Problem:
 * Read a list of names (one per line) from a text file, store these names in an array of name
 * objects, sort the name objects, then display the sorted name objects on the screen. In addition,
 * a file containing the sorted names must be created.
 */
public class Name {
    // Declare private variables to store the last and first names
    public String lastName;
    public String firstName;

    /**
     * Constructor for the Name class that initializes the first and last names.
     * @param lastName  The last name of the person
     * @param firstName The first name of the person
     */
    public Name(String lastName, String firstName) {
        this.lastName = lastName;
        this.firstName = firstName;
    }

    /**
     * Setter method to set the first name.
     * @param firstName The first name to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Setter method to set the last name.
     * @param lastName The last name to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Getter method to get the first name.
     * @return The first name of the person
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Getter method to get the last name.
     * @return The last name of the person
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Overridden toString method to display the name in the "Last, First" format.
     * @return A string representation of the name in the "Last, First" format
     */
    @Override
    public String toString() {
        return lastName + ", " + firstName;
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
}

