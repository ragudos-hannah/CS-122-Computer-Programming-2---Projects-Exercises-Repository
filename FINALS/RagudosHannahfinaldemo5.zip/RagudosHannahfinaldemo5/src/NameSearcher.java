/**
 * Name: Ragudos, Hannah T
 * Activity:  Final Review Programming Exercise 2 ( On Searching)
 * Date: 05/12/2023
 *
 * Objective:
 * Create a program that implements the following:
 * 1. Linear Search Algorithm
 * 2. Binary Search Algorithm
 *
 * Problem:
 * Read a list of names (one per line) from a text file, store these names in an array of name
 * objects, search the list to determine if a name specified by the user at runtime is in the array.
 *
 * Sample Run:
 * CASE 1:
 * This program sorts a list of names stored in a file.
 *
 * Enter the name of the file that contains the list of names: List1.txt
 *
 * List of Names
 * Juan, Dela Cruz
 * Renator, Osmena
 * Santos, Abad
 * Theodore, Valdez
 *
 * Enter the first name you want to search: Juan
 * Enter the last name you want to search: Dela Cruz
 *
 * Enter the search algorithm to be applied:
 * [1] Binary Search
 * [2] Linear Search
 *
 *
 * Searching...
 *
 * DONE.
 *
 * The name Juan, Dela Cruz is found on the list
 *
 * Repeat the process(Y/N)?
 * Y
 *
 * Enter the first name you want to search: Juan
 *Enter the last name you want to search: Dela Cruz
 *
 *  Enter the search algorithm to be applied:
 *  [1] Binary Search
 *  [2] Linear Search
 *  2
 *
 * Searching...
 *
 * DONE.
 *
 * The name Richard, Karen is not found in the list.
 *
 */

// The NameSorter main class

import java.io.*;
import java.util.*;

public class NameSearcher {
    /**
     * Reads names from a file, creates Name objects, and stores them in an array.
     * @param fileName The name of the input file containing the list of names.
     * @return An array of Name objects.
     */
    private static Name[] readFromFile(String fileName) {
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            int numNames = Integer.parseInt(bufferedReader.readLine().trim());
            Name[] names = new Name[numNames];

            for (int i = 0; i < numNames; i++) {
                String[] nameParts = bufferedReader.readLine().split(", ");
                names[i] = new Name(nameParts[1], nameParts[0]);
            } // End of For
            bufferedReader.close();
            return names;
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
            return new Name[0];
        } // End of try-catch block
    } //  End of readFromFile method

    /**
     * Search a Name using the Binary Search algorithm.
     */
    private static void binarySearch(Name[] names, Name searchKey) {
        int left = 0;
        int right = names.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int res = names[mid].compareTo(searchKey);

            if (res == 0) {
                System.out.println("The name " + searchKey + " is found on the list");
                return;
            }
            if (res > 0) {
                right = mid - 1;
            } else {
                left = mid + 1;
            } // End of else
        } // end of if
        System.out.println("The name " + searchKey + " is not found in the list.");
    } // End of binarySearch method

    /**
     * Search a Name using the Linear Search algorithm.
     */
    private static void linearSearch(Name[] names, Name searchKey) {
        for (int i = 0; i < names.length; i++) {
            if (names[i].equals(searchKey)) {
                System.out.println("The name " + searchKey + " is found on the list");
                return;
            } // End of if
        } // End of for
        System.out.println("The name " + searchKey + " not found in the list.");
    } // end of linearSearch method

    /**
     * Main entry of the program
     * @param args
     */
    public static void main(String[] args) {
        // Initialize a Scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Print the program description
        System.out.println("This program sorts a list of names stored in a file.");
        System.out.print("\nEnter the name of the file that contains the list of names: ");
        String fileName = scanner.nextLine();
        Name[] names = readFromFile(fileName);

        // Shows the content of the file
        Arrays.sort(names);
        System.out.println("\nList of Names");
        for (Name name : names) {
            System.out.println(name);
        }

        // Prompt the user for entering name to be searched
        System.out.print("\nEnter the first name you want to search: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter the last name you want to search: ");
        String lastName = scanner.nextLine();

        // Read names from the file and store them in an array of Name objects
        Name target = new Name(lastName, firstName);

        // Initialize a flag to control the loop for searching
        boolean repeat = true;
        while (repeat) {

        // Prompt the user for the chosen search algorithm
        System.out.print("\nEnter the search algorithm to be applied:\n[1] Binary Search\n[2] Linear Search\n ");
        int choice = scanner.nextInt();
        if (choice == 1) {
            binarySearch(names, target);
        } else if (choice == 2) {
            linearSearch(names, target);
        } else {
            System.out.println("\nInvalid option.");
        }

        // Search the name using the selected searching algorithm
        System.out.println("\nSearching...");
        System.out.println("\nDONE.");

            // Ask the user if they want to repeat the process with a different searching algorithm
            System.out.print("\nRepeat the process(Y/N)? ");
            String response = scanner.next();
            repeat = response.equalsIgnoreCase("Y");
        }
        scanner.close();
    } // End of the main method
} // End NameSearcher class
