/**
 * Name: Ragudos, Hannah T
 * Activity:  Final Review Programming Exercise 2 ( On Searching)
 * Date: 05/12/2023
 *
 * Objective:
 * Create a program that implements the following:
 * 1. Linear Search Algorithm
 * 2. Binary Search Algorithm
 *
 * Problem:
 * Read a list of names (one per line) from a text file, store these names in an array of name
 * objects, search the list to determine if a name specified by the user at runtime is in the array.
 */

// The Name Reference Class
public class Name implements Comparable<Name> {
    // Declare private variables to store the first and last names
    private String firstName;
    private String lastName;

    /**
     * Constructor for the Name class that initializes the first and last names.
     * @param firstName The first name of the person
     * @param lastName  The last name of the person
     */
    public Name(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * Setter method to set the first name.
     * @param firstName The first name to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Setter method to set the last name.
     * @param lastName The last name to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Getter method to get the first name.
     * @return The first name of the person
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Getter method to get the last name.
     * @return The last name of the person
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Overridden toString method to display the name in the "Last, First" format.
     * @return A string representation of the name in the "Last, First" format
     */
    @Override
    public String toString() {
        return lastName + ", " + firstName;
    }

    /**
     * Overridden compareTo method to compare the Name to other object.
     *  @param other The object to be compared
     * @return void
     */
    @Override
    public int compareTo(Name other) {
        int lastNameComparison = lastName.compareTo(other.lastName);
        return lastNameComparison != 0 ? lastNameComparison : firstName.compareTo(other.firstName);
    }

    /**
     * Overrides equals method in class Object
     * @return void
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Name)) return false;
        Name name = (Name) o;
        return firstName.equals(name.firstName) && lastName.equals(name.lastName);
    }
}
